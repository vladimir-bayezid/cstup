
# Auto Script, By YUJINZ BARBOZA (087775474442)
=================================================================================

# debian7.sh
```
wget https://overses.net/debian7//debian7.sh && chmod +x ./debian7.sh && ./debian7.sh
```
# OPENVPN
```
wget -O openvpn.sh https://raw.githubusercontent.com/join-x/y/debian7/openvpn.sh && chmod +x openvpn.sh && ./openvpn.sh
```
# TERIMA KASIH YA ALLAH SWT ATAS SEMUANYA
=================================================================================
