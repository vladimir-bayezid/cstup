            echo "Servie squid restart .................tunggu sebentar"
            sleep 0.3
            service squid3 restart
            echo ""
	    echo "Script Created by http://www.overses.net"
            echo "Terimakasih sudah berlanggan di overses.net"
