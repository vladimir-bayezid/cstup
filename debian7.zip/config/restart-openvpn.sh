            echo "Servie openvpn restart .................tunggu sebentar"
            sleep 0.3
            service openvpn restart
            echo ""
	    echo "Script Created by http://www.overses.net"
            echo "Terimakasih sudah berlanggan di overses.net"
